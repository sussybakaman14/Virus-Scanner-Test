Hi i am sussybakaman14.
This is the safety version.
I don't think i made the non-safety version.
Enjoy

WIP