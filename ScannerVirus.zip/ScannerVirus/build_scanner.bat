@echo off
title Compilazione Scanner Antivirus

echo ---------------------------------------
echo   COMPILAZIONE CON MINGW-W64
echo ---------------------------------------

REM Controlla se gcc esiste
where gcc >nul 2>&1
if %errorlevel% neq 0 (
    echo ERRORE: gcc non trovato. Assicurati che MinGW-w64 sia nel PATH.
    pause
    exit /b
)

echo Compilo scanner.c ...
gcc scanner.c -O2 -s -o scanner.exe

if %errorlevel% neq 0 (
    echo.
    echo *** COMPILAZIONE FALLITA ***
    pause
    exit /b
)

echo.
echo *** COMPILAZIONE COMPLETATA ***
echo File generato: scanner.exe

echo.
echo Avvio lo scanner...
scanner.exe

echo.
pause
