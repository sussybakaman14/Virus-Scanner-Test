#include <windows.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct {
    char name[64];
    unsigned char *bytes;
    size_t length;
} VirusSignature;

typedef struct {
    VirusSignature *items;
    size_t count;
} SignatureDB;

static long total_files = 0;
static long scanned_files = 0;

// ------------------------------------------------------------
// Cartelle da escludere
// ------------------------------------------------------------
int should_skip_directory(const char *path) {
    const char *system_dirs[] = {
        "C:\\Windows",
        "C:\\Program Files",
        "C:\\Program Files (x86)",
        "C:\\ProgramData",
        "C:\\$Recycle.Bin",
        "C:\\System Volume Information",
        NULL
    };

    for (int i = 0; system_dirs[i] != NULL; i++) {
        if (_strnicmp(path, system_dirs[i], strlen(system_dirs[i])) == 0) {
            return 1;
        }
    }

    return 0;
}

// ------------------------------------------------------------
// Conta i file totali
// ------------------------------------------------------------
void count_files(const char *path) {
    char searchPath[MAX_PATH];
    snprintf(searchPath, MAX_PATH, "%s\\*", path);

    WIN32_FIND_DATAA fd;
    HANDLE h = FindFirstFileA(searchPath, &fd);
    if (h == INVALID_HANDLE_VALUE) return;

    do {
        if (strcmp(fd.cFileName, ".") == 0 || strcmp(fd.cFileName, "..") == 0)
            continue;

        char fullPath[MAX_PATH];
        snprintf(fullPath, MAX_PATH, "%s\\%s", path, fd.cFileName);

        if (fd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) {

            if (should_skip_directory(fullPath))
                continue;

            count_files(fullPath);
        } else {
            total_files++;
        }

    } while (FindNextFileA(h, &fd));

    FindClose(h);
}

// ------------------------------------------------------------
// Barra di avanzamento
// ------------------------------------------------------------
void show_progress() {
    if (total_files == 0) return;

    float percent = (float)scanned_files / total_files * 100.0f;
    int bars = (int)(percent / 5); // 20 step

    printf("\r[");
    for (int i = 0; i < 20; i++) {
        if (i < bars) printf("#");
        else printf("-");
    }
    printf("] %.1f%% (%ld/%ld file)", percent, scanned_files, total_files);
    fflush(stdout);
}

// ------------------------------------------------------------
// Caricamento firme
// ------------------------------------------------------------
int load_signatures(const char *path, SignatureDB *db) {
    FILE *f = fopen(path, "r");
    if (!f) {
        printf("Impossibile aprire %s\n", path);
        return -1;
    }

    db->items = NULL;
    db->count = 0;

    char line[512];
    while (fgets(line, sizeof(line), f)) {
        char *eq = strchr(line, '=');
        if (!eq) continue;

        *eq = '\0';
        char *name = line;
        char *hexpart = eq + 1;

        char *nl = strchr(hexpart, '\n');
        if (nl) *nl = '\0';

        size_t len = 0;
        char *p = hexpart;
        while (*p) {
            while (*p == ' ') p++;
            if (!*p) break;
            len++;
            while (*p && *p != ' ') p++;
        }

        unsigned char *bytes = malloc(len);
        if (!bytes) continue;

        size_t idx = 0;
        p = hexpart;
        while (*p && idx < len) {
            while (*p == ' ') p++;
            if (!*p) break;
            unsigned int val;
            sscanf(p, "%2x", &val);
            bytes[idx++] = (unsigned char)val;
            while (*p && *p != ' ') p++;
        }

        db->items = realloc(db->items, (db->count + 1) * sizeof(VirusSignature));
        VirusSignature *vs = &db->items[db->count++];
        strncpy(vs->name, name, sizeof(vs->name)-1);
        vs->name[sizeof(vs->name)-1] = '\0';
        vs->bytes = bytes;
        vs->length = len;
    }

    fclose(f);
    return 0;
}

// ------------------------------------------------------------
// Scansione file
// ------------------------------------------------------------
void scan_file(const char *path, const SignatureDB *db) {
    scanned_files++;
    show_progress();

    printf("\nScansiono: %s\n", path);

    FILE *f = fopen(path, "rb");
    if (!f) return;

    fseek(f, 0, SEEK_END);
    long size = ftell(f);
    fseek(f, 0, SEEK_SET);

    if (size <= 0) {
        fclose(f);
        return;
    }

    unsigned char *buffer = malloc(size);
    if (!buffer) {
        fclose(f);
        return;
    }

    fread(buffer, 1, size, f);
    fclose(f);

    for (size_t s = 0; s < db->count; s++) {
        VirusSignature *vs = &db->items[s];
        for (long i = 0; i <= size - (long)vs->length; i++) {
            if (memcmp(buffer + i, vs->bytes, vs->length) == 0) {
                printf("[INFETTO] %s -> %s\n", path, vs->name);
                free(buffer);
                return;
            }
        }
    }

    free(buffer);
}

// ------------------------------------------------------------
// Scansione ricorsiva directory
// ------------------------------------------------------------
void scan_directory(const char *path, const SignatureDB *db) {
    char searchPath[MAX_PATH];
    snprintf(searchPath, MAX_PATH, "%s\\*", path);

    WIN32_FIND_DATAA fd;
    HANDLE h = FindFirstFileA(searchPath, &fd);
    if (h == INVALID_HANDLE_VALUE) return;

    do {
        if (strcmp(fd.cFileName, ".") == 0 || strcmp(fd.cFileName, "..") == 0)
            continue;

        char fullPath[MAX_PATH];
        snprintf(fullPath, MAX_PATH, "%s\\%s", path, fd.cFileName);

        if (fd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) {

            if (should_skip_directory(fullPath)) {
                printf("\n[SKIP] %s\n", fullPath);
                continue;
            }

            scan_directory(fullPath, db);
        } else {
            scan_file(fullPath, db);
        }

    } while (FindNextFileA(h, &fd));

    FindClose(h);
}

// ------------------------------------------------------------
// MAIN
// ------------------------------------------------------------
int main() {
    SignatureDB db;

    if (load_signatures("signatures.txt", &db) != 0) {
        printf("Errore nel caricamento delle firme.\n");
        return 1;
    }

    printf("Conteggio file...\n");
    count_files("C:\\");
    printf("Trovati %ld file.\n", total_files);

    printf("Inizio scansione...\n");
    scan_directory("C:\\", &db);

    printf("\n\nScansione completata.\n");
    return 0;
}
